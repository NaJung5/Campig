package org.camping.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.camping.model.EquipDTO;


public interface EquipMapper {
	
	public int getEquipCount(HashMap<String,Object> map);
	public int getEquipListCount(HashMap<String,Object> map);
	public List<EquipDTO> getEquipList(HashMap<String,Object> map);
	
	public void equipInsert(EquipDTO dto);
	
	public int equipFavoriteInsert (HashMap<String,Object> equipFavorite);
	public int equipFavoriteCount (HashMap<String,Object> equipFavorite);
	public int equipFavoriteDelete (HashMap<String,Object> equipFavorite);
	
	public int equipFavoriteCnt (HashMap<String,Object> map);
	
	public List<EquipDTO> getEqAllList(@Param("startRow") int startRow, @Param("endRow") int endRow);
	public int getEqAllCount();
	
}
