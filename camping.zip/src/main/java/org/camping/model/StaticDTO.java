package org.camping.model;

import lombok.Data;

@Data
public class StaticDTO {
	
	public String staticName;
	public int staticValue;
	
	public String fil;

	
	

}
