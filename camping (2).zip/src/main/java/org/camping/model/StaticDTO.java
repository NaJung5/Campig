package org.camping.model;

public class StaticDTO {

}
